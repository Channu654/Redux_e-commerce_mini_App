import { type } from '@testing-library/user-event/dist/type';
import axios from 'axios';
import * as types from './ActionType';

export const getdata = (payload) => (dispatch) => {
  dispatch({ type: types.GET_DATA_REQUEST });
  return axios
    .get('http://localhost:8080/data')
    .then((res) =>
      dispatch({ type: types.GET_DATA_SUCCESS, payload: res.data })
    )
    .catch((err) => dispatch({ type: types.GET_DATA_FAILURE(err) }));
};

// single product

export const singleproduct = (id) => (dispatch) => {
  type({ type: types.SINGLE_PRODUCT_REQUEST });
  return axios
    .get(`http://localhost:8080/data/${id}`)
    .then((res) =>
      dispatch({ type: types.SINGLE_PRODUCT_SUCCESS, payload: res.data })
    )
    .catch((err) => dispatch({ type: types.SINGLE_PRODUCT_FAILURE }));
};

// addto cart

export const AddtoCart = (payload) => (dispatch) => {
  dispatch({ type: types.ADDTO_CART_REQUEST });
  return axios
    .post('http://localhost:8080/cart', payload)
    .then((res) =>
      dispatch({ type: types.ADDTO_CART_SUCCESS, payload: res.data })
    )
    .catch((err) => dispatch({ type: types.ADDTO_CART_FAILURE }));
};

// INCREASE QTY
export const increaseQty = (id) => (dispatch) => {
  return axios
    .post(`http://localhost:8080/data/${id}`)
    .then((res) => dispatch({ type: types.INCREASE_QTY, id: res.data }));
};

// DECREASE QTY
export const decreaseQty = (id) => (dispatch) => {
  return axios
    .post('http://localhost:8080/cart')
    .then((res) => dispatch({ type: types.DECREASE_QTY, id: res.data }));
};

// REMOVE QTY
export const removeQty = (id) => (dispatch) => {
  return axios
    .post(`http://localhost:8080/data/${id}`)
    .then((res) => dispatch({ type: types.REMOVE_QTY, id: res.data }));
};
