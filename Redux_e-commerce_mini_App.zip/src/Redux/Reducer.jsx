import * as types from './ActionType';
const initState = {
  isLoading: false,
  isError: false,
  data: [],
  currentProduct: {},
  cart: [],
};

export const reducer = (state = initState, { type, payload }) => {
  switch (type) {
    case types.GET_DATA_REQUEST:
      return {
        ...state,
        isLoading: true,
        isError: false,
      };
    case types.GET_DATA_SUCCESS:
      return {
        ...state,
        isLoading: false,
        isError: false,
        data: payload,
      };
    case types.GET_DATA_FAILURE:
      return {
        ...state,
        isLoading: false,
        isError: true,
      };

    // single**********************

    case types.SINGLE_PRODUCT_REQUEST: {
      return {
        ...state,
        isLoading: true,
        isError: false,
      };
    }
    case types.SINGLE_PRODUCT_SUCCESS:
      return {
        ...state,
        isLoading: false,
        isError: false,
        currentProduct: payload,
      };
    case types.SINGLE_PRODUCT_FAILURE:
      return {
        ...state,
        isLoading: false,
        isError: true,
      };

    // addto cart***********************

    case types.ADDTO_CART_SUCCESS:
      // let check cart same product is present in cart or not
      const isPresent = state.cart.find((prod) => {
        return prod.id === payload.id;
      });

      // if its present increase qty
      let newcart;
      if (isPresent) {
        let newcart = state.cart.map((prod) => {
          // console.log('newcart:', newcart)

          if (prod.id === payload.id) {
            return { ...prod, qty: prod.qty + 1 };
          } else {
            return prod;
          }
        });
      } else {
        let newPayload = {
          ...payload,
          qty: 1,
        };
        newcart = [...state.cart, newPayload];
      }
      return { ...state, cart: newcart };

    // *********************************INCREASE QTY*******
    case types.INCREASE_QTY:
      let modifiedCart = state.cart.map((item) => {
        if (item.id === payload.id) {
          return { ...item, item: item.qty + 1 };
        } else {
          return item;
        }
      });
      return { ...state, cart: modifiedCart };

    // **********DECREASE QTY*******
    case types.DECREASE_QTY:
      let resultantCart = state.cart.map((item) => {
        if (item.id === payload.id) {
          return { ...item, item: item.qtyqty - 1 };
        } else {
          return item;
        }
      });
      return { ...state, cart: resultantCart };

    // *************REMOVE QTY********************
    case types.REMOVE_QTY:
      let updatedCart = state.cart.filter((prod) => {
        return !(prod.id === payload.id);
      });

      return { ...state, cart: updatedCart };

    default:
      return { ...state };
  }
};
