import React, { useState } from 'react';
import { Flex, Image, Spacer, Text, Icon } from '@chakra-ui/react';
import { Link } from 'react-router-dom';
import { BsSearch, BsBasket3 } from 'react-icons/bs';
import { FiUser } from 'react-icons/fi';
import { useDispatch, useSelector } from 'react-redux';
import {
  Drawer,
  DrawerBody,
  DrawerFooter,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  useDisclosure,
  Box,
  Button,
} from '@chakra-ui/react';
import { decreaseQty, increaseQty } from '../Redux/Action';

const Navbar = () => {
  const Addto_cart = useSelector((state) => state.reducer.cart);
  console.log('Addto_cart:', Addto_cart);

  const dispatch = useDispatch();

  const { isOpen, onOpen, onClose } = useDisclosure();
  const btnRef = React.useRef();

  const handleDecrease = (id) => {};

  const handleIncrease = (id) => {
    dispatch(increaseQty({ id }));
  };
  return (
    <Flex bg='#e1ebe4' fontSize={12} position={'fixed'} width={'100%'}>
      <Image
        src='https://cdn.shopify.com/s/files/1/0258/2485/4100/files/flatheads-logo-new-hotizontal_180x_2x_bf74c8db-79f1-4904-b343-3b0e2681ec07_192x32.png?v=1647508945'
        alt='Dan Abramov'
        m={5}
      />
      <Spacer />
      <Link to='/collection/all'>
        <Text px={6} py={5}>
          SHOP{' '}
        </Text>
      </Link>
      <Link to='/collection/all'>
        <Text px={6} py={5}>
          WOMEN
        </Text>
      </Link>
      <Link to='/collection/all'>
        <Text px={6} py={5}>
          MEN
        </Text>
      </Link>
      <Link to='/collection/all'>
        <Text px={6} py={5}>
          NEW ARRIVALS
        </Text>
      </Link>
      <Link to='/collection/all'>
        <Text px={6} py={5}>
          ABOUT
        </Text>
      </Link>
      <Link to='/collection/all'>
        <Text px={6} py={5}>
          HELP
        </Text>
      </Link>
      <Spacer />
      <Icon as={BsSearch} m={5} />
      <Icon as={FiUser} m={5} />

      <Icon
        as={BsBasket3}
        m={5}
        ref={btnRef}
        colorScheme='teal'
        onClick={onOpen}
        cursor
      />
      <Text position={'absolute'} ml={1060} py={2}>
        {Addto_cart ? Addto_cart.length : 0}
      </Text>
      <Drawer
        isOpen={isOpen}
        placement='right'
        onClose={onClose}
        finalFocusRef={btnRef}>
        <DrawerOverlay />
        <DrawerContent>
          <DrawerCloseButton />
          <DrawerHeader>YOUR CART ({Addto_cart.length})</DrawerHeader>

          <DrawerBody>
            {Addto_cart.length > 0 &&
              Addto_cart.map((item) => {
                console.log('item:', item);
                return (
                  <Flex gap={5} m={3} key={item.id}>
                    <Image src={item.image} w={12} />
                    <Text fontSize={12}>{item.title}</Text>
                    <h1>${item.price}</h1>
                    <Flex>
                      <Button
                        _disabled={item.qty < 1}
                        onClick={() => handleDecrease(item.qty)}>
                        -
                      </Button>
                      <Text>{item.qty}</Text>
                      <Button onClick={() => handleIncrease()}>
                        +
                      </Button>
                    </Flex>
                  </Flex>
                );
              })}
          </DrawerBody>

          <DrawerFooter>
            <Button variant='outline' mr={3} onClick={onClose}>
              Cancel
            </Button>
            <Button colorScheme='blue'>Save</Button>
          </DrawerFooter>
        </DrawerContent>
      </Drawer>
    </Flex>
  );
};

export default Navbar;
