import React from "react";

const Filter = () => {
  return <div>Filter</div>;
};

export default Filter;
